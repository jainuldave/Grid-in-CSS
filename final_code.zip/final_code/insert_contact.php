<?php
 include("config.php");

 
if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
}

$name = $_POST['name'];
$number = $_POST['number'];
$city = $_POST['city'];
$pid = $_POST['pid'];

// Insert data into the database (replace with your database table and columns)
$sql = "INSERT INTO user_contact (name, number, city,pid) VALUES ('$name', '$number', '$city','$pid')";

if ($con->query($sql) === TRUE) {
    // Retrieve the contact details and return them
    $contactDetails = "Name: $name<br>Number: $number<br>City: $city";
    echo $contactDetails;
} else {
    echo "Error: " . $sql . "<br>" . $con->error;
}

$con->close();
?>
