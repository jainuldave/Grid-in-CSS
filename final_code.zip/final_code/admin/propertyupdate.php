<?php
include("config.php");
$pid = $_GET['id'];
$action = $_GET['action'];
$sql = "UPDATE property property SET post_status ='$action' WHERE pid = {$pid}";
$result = mysqli_query($con, $sql);
if($result == true)
{
	$msg="<p class='alert alert-success'>Property Updated</p>";
	header("Location:propertyview.php?msg=$msg");
}
else{
	$msg="<p class='alert alert-warning'>Property Not Updated</p>";
	header("Location:propertyview.php?msg=$msg");
}
mysqli_close($con);
?>