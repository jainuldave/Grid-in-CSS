<?php
session_start();
require("config.php");
////code
 
if(!isset($_SESSION['auser']))
{
	header("location:index.php");
}
 // Function to generate a random name for the image
function generateRandomName($fileExtension) {
    $characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    $randomString = '';
    $length = 10; // You can adjust the length of the random string as needed

    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, strlen($characters) - 1)];
    }

    return $randomString . '.' . $fileExtension;
}
$error = "";
$msg = "";
//get the property data
if (isset($_GET['id'])) {
    $uid = $_GET['id'];

    // Fetch the blog post from the database
    $stmt = mysqli_prepare($con, "SELECT * FROM property WHERE pid = ?");
    mysqli_stmt_bind_param($stmt, "i", $uid);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if ($row = mysqli_fetch_assoc($result)) {
        $propertyData = $row;
    } else {
        $msg = "<p class='alert alert-warning'>property not found</p>";
    }

    mysqli_stmt_close($stmt);
}
$test="";
if (isset($_POST['add'])) {
    $pid = $_REQUEST['id'];
    $title = $_POST['title'];
    $project_reg_number = $_POST['project_reg_number']; //1
    $agent_reg_number = $_POST['agent_reg_number']; //2
   	$qr_code_image  = $_FILES['qr_code']['name'];
    if(empty($qr_code_image)){
    	 $qr_code_image= $propertyData['qr_code'];	
    }
    else{
    	 $temp_name_qr = $_FILES['qr_code']['tmp_name'];
    	 $randomName9 = generateRandomName(pathinfo($qr_code_image, PATHINFO_EXTENSION));
    	 move_uploaded_file($temp_name_qr, "property/$randomName9");
    	 $qr_code_image = $randomName9;
    	 
    }
    $content =  $_POST['content'];
    $ptype = $_POST['ptype'];
    $bhk = $_POST['bhk'];
    $bed = $_POST['bed'];
    $balc = $_POST['balc'];
    $hall = $_POST['hall'];
    $stype = $_POST['stype'];
    $bath = $_POST['bath'];
    $kitc = $_POST['kitc'];
    $floor = $_POST['floor'];
     $totalfloor = $_POST['totalfl'];
    $price = $_POST['price'];
    $city = $_POST['city'];
    $asize = $_POST['asize'];
    $loc = $_POST['loc'];
    $state = $_POST['state'];
    $feature =   $_POST['feature'];
    $faceing = $_POST['faceing'];
    $youtube_code = $_POST['youtube_code'];
    //property image 
    $aimage = $_FILES['aimage']['name'];
    if(empty($aimage)){
    	 $aimage= $propertyData['pimage'];	
    }
    else{
    	 $temp_name_qr = $_FILES['aimage']['tmp_name'];
    	 $randomName19 = generateRandomName(pathinfo($aimage, PATHINFO_EXTENSION));
    	 move_uploaded_file($temp_name_qr, "property/$randomName19");
    	 $aimage = $randomName19;
    	 
    }
     //property image 1
  	$aimage1 = $_FILES['aimage1']['name'];
    if(empty($aimage1)){
    	 $aimage1= $propertyData['pimage1'];	
    }
    else{
    	 $temp_name_qr = $_FILES['aimage1']['tmp_name'];
    	 $randomName119 = generateRandomName(pathinfo($aimage1, PATHINFO_EXTENSION));
    	 move_uploaded_file($temp_name_qr, "property/$randomName119");
    	 $aimage1 = $randomName119;
    	 
    }
     //property image 2
	$aimage2 = $_FILES['aimage2']['name'];
    if(empty($aimage2)){
    	 $aimage2= $propertyData['pimage2'];	
    }
    else{
    	 $temp_name_qr = $_FILES['aimage2']['tmp_name'];
    	 $randomName1119 = generateRandomName(pathinfo($aimage2, PATHINFO_EXTENSION));
    	 move_uploaded_file($temp_name_qr, "property/$randomName1119");
    	 $aimage2 = $randomName1119;
    	 
    }
    //property image 3
    $aimage3 = $_FILES['aimage3']['name'];
    if(empty($aimage3)){
    	 $aimage3= $propertyData['pimage3'];	
    }
    else{
    	 $temp_name_qr = $_FILES['aimage3']['tmp_name'];
    	 $randomName11119 = generateRandomName(pathinfo($aimage3, PATHINFO_EXTENSION));
    	 move_uploaded_file($temp_name_qr, "property/$randomName11119");
    	 $aimage3 = $randomName11119;
    	 
    }
     //property image 4
    $aimage4 = $_FILES['aimage4']['name'];
    if(empty($aimage4)){
    	 $aimage4= $propertyData['pimage4'];	
    }
    else{
    	 $temp_name_qr = $_FILES['aimage4']['tmp_name'];
    	 $randomName111119 = generateRandomName(pathinfo($aimage4, PATHINFO_EXTENSION));
    	 move_uploaded_file($temp_name_qr, "property/$randomName111119");
    	 $aimage4 = $randomName111119;
    	 
    }
    //map_image
     $fimage = $_FILES['fimage']['name'];
     if(empty($fimage)){
    	 $fimage= $propertyData['mapimage'];	
    }
    else{
    	 $temp_name_qr = $_FILES['fimage']['tmp_name'];
    	 $randomName1111119 = generateRandomName(pathinfo($fimage, PATHINFO_EXTENSION));
    	 move_uploaded_file($temp_name_qr, "property/$randomName1111119");
    	 $fimage = $randomName1111119;
    	 
    }
    //basement image
     //map_image
     $fimage1 = $_FILES['fimage1']['name'];
     if(empty($fimage1)){
    	 $fimage1= $propertyData['topmapimage'];	
    }
    else{
    	 $temp_name_qr = $_FILES['fimage1']['tmp_name'];
    	 $randomName11111119 = generateRandomName(pathinfo($fimage1, PATHINFO_EXTENSION));
    	 move_uploaded_file($temp_name_qr, "property/$randomName11111119");
    	 $fimage1 = $randomName11111119;
    	 
    }
    //Ground Floor Plan Image
     $fimage2 = $_FILES['fimage2']['name'];
      if(empty($fimage2)){
    	 $fimage2= $propertyData['topmapimage'];	
    }
    else{
    	 $temp_name_qr = $_FILES['fimage2']['tmp_name'];
    	 $randomName111111119 = generateRandomName(pathinfo($fimage2, PATHINFO_EXTENSION));
    	 move_uploaded_file($temp_name_qr, "property/$randomName111111119");
    	 $fimage2 = $randomName111111119;
    	 
    }
     $isFeatured = $_POST['isFeatured'];
     $status = $_POST['status'];
    $query = "UPDATE property SET title = '$title',project_reg_number='$project_reg_number',agent_reg_number='$agent_reg_number',qr_code='$qr_code_image',pcontent='$content',type='$ptype',bhk='$bhk',bedroom='$bed',balcony='$balc',hall='$hall',stype='$stype',bathroom='$bath',kitchen='$kitc',floor='$floor',price='$price',city='$city',size='$asize',location='$loc',state='$state',feature='$feature',faceing='$faceing',pimage='$aimage',pimage1='$aimage1',pimage2='$aimage2',pimage3='$aimage3',pimage4='$aimage4',mapimage='$fimage',topmapimage='$fimage1',groundmapimage='$fimage2',isFeatured='$isFeatured',status='$status',youtube_code='$youtube_code',totalfloor='$totalfloor' WHERE pid = '$pid'";

    // Execute the SQL query
    if (mysqli_query($con, $query) === TRUE) {
        $msg = "<p class='alert alert-success'>Property Updated</p>";
        // header("Location:?msg=$msg&id=$pid");
    } else {
        $msg = "<p class='alert alert-danger'>Property Not Updated</p>";
        $msg = mysqli_error($con);
        // header("Location:?msg=$msg&id=$pid");
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
        <title>Edit Property</title>
		
		<!-- Favicon -->
        <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.png">
		
		<!-- Bootstrap CSS -->
        <link rel="stylesheet" href="assets/css/bootstrap.min.css">
		
		<!-- Fontawesome CSS -->
        <link rel="stylesheet" href="assets/css/font-awesome.min.css">
		
		<!-- Feathericon CSS -->
        <link rel="stylesheet" href="assets/css/feathericon.min.css">
		
		<!-- Main CSS -->
        <link rel="stylesheet" href="assets/css/style.css">
		
		<!--[if lt IE 9]>
			<script src="assets/js/html5shiv.min.js"></script>
			<script src="assets/js/respond.min.js"></script>
		<![endif]-->
    </head>
    <body>

		
			<!-- Header -->
			<?php include("header.php"); ?>
			<!-- /Sidebar -->
			
			<!-- Page Wrapper -->
            <div class="page-wrapper">
                <div class="content container-fluid">
				
					<!-- Page Header -->
					<div class="page-header">
						<div class="row">
							<div class="col">
								<h3 class="page-title">Property</h3>
								<ul class="breadcrumb">
									<li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
									<li class="breadcrumb-item active">Property</li>
								</ul>
							</div>
						</div>
					</div>
					<!-- /Page Header -->
					
					<div class="row">
						<div class="col-md-12">
							<div class="card">
								<div class="card-header">
									<h4 class="card-title">Update Property Details</h4>
									<?php echo $error; ?>
									<?php echo $msg; ?>
									<?php echo $test; ?>
								</div>
								<?php
									
									$pid=$_GET['id'];
									$query=mysqli_query($con,"select * from property where pid='$pid'");
									while($row=mysqli_fetch_assoc($query))
									{
								?>	

								<form method="post" enctype="multipart/form-data">
								<div class="card-body">
									<h5 class="card-title">Property Detail</h5>
									 
									
										<div class="row">
											<div class="col-xl-12">
												<div class="form-group row">
													<label class="col-lg-2 col-form-label">Title</label>
													<div class="col-lg-9">
														<input type="text" class="form-control" name="title" required placeholder="Enter Title" value="<?php echo $row['title']; ?>">
													</div>
												</div>
												<?php
													$user_id_pro= $row['uid'];
													$sql_user = "SELECT utype FROM user WHERE uid = '$user_id_pro' ";
													if($result_utype =mysqli_query($con,$sql_user)){
														while($row_utype = mysqli_fetch_assoc($result_utype)){
															 if($row_utype['utype']=='owner'){

															 }
															 else if($row_utype['utype']=='agent'){
															 
															 	echo '
															    <div class="form-group row">
															        <label class="col-lg-2 col-form-label">Agent Maharashtra Registration Number (Optional)</label>
															        <div class="col-lg-9">
															            <input type="text" class="form-control" name="agent_reg_number" placeholder="Enter Agent Registration Number" value="' . htmlspecialchars($row['agent_reg_number']) . '">
															        </div>
															    </div>';

															 }
															 else if($row_utype['utype']=='builder/developer'){
															 	echo '<div class="form-group row">
															    <label class="col-lg-2 col-form-label">Project Maharashtra Registration Number (Optional)</label>
															    <div class="col-lg-9">
															        <input type="text" class="form-control" name="project_reg_number" placeholder="Enter Maharashtra Registration Number" value="' . htmlspecialchars($row['project_reg_number']) . '">
															    </div>
															</div>';

															echo '<div class="form-group row">
															    <label class="col-lg-2 col-form-label">QR Code upload (Optional)</label>
															    <div class="col-lg-9">
															        <input type="file" class="form-control" name="qr_code" placeholder="Enter Maharashtra Registration Number">

															    
															';
															echo '<img src="property/' . htmlspecialchars($row['qr_code']) . '" alt="pimage" height="150" width="180"></div></div>';


															}
															 else if($row_utype['utype']=='channel partner'){
															 	echo '
															    <div class="form-group row">
															        <label class="col-lg-2 col-form-label">Agent Maharashtra Registration Number (Optional)</label>
															        <div class="col-lg-9">
															            <input type="text" class="form-control" name="agent_reg_number" placeholder="Enter Agent Registration Number" value="' . htmlspecialchars($row['agent_reg_number']) . '">
															        </div>
															    </div>';
															    echo '<div class="form-group row">
															    <label class="col-lg-2 col-form-label">Project Maharashtra Registration Number (Optional)</label>
															    <div class="col-lg-9">
															        <input type="text" class="form-control" name="project_reg_number" placeholder="Enter Maharashtra Registration Number" value="' . htmlspecialchars($row['project_reg_number']) . '">
															    </div>
															</div>';
															echo '<div class="form-group row">
															    <label class="col-lg-2 col-form-label">QR Code upload (Optional)</label>
															    <div class="col-lg-9">
															        <input type="file" class="form-control" name="qr_code" placeholder="Enter Maharashtra Registration Number">

															    
															';
															echo '<img src="property/' . htmlspecialchars($row['qr_code']) . '" alt="pimage" height="150" width="180"></div></div>';
															 }
															 	 else if($row_utype['utype']=='strategic partner'){
															 	echo '
															    <div class="form-group row">
															        <label class="col-lg-2 col-form-label">Agent Maharashtra Registration Number (Optional)</label>
															        <div class="col-lg-9">
															            <input type="text" class="form-control" name="agent_reg_number" placeholder="Enter Agent Registration Number" value="' . htmlspecialchars($row['agent_reg_number']) . '">
															        </div>
															    </div>';
															    echo '<div class="form-group row">
															    <label class="col-lg-2 col-form-label">Project Maharashtra Registration Number (Optional)</label>
															    <div class="col-lg-9">
															        <input type="text" class="form-control" name="project_reg_number" placeholder="Enter Maharashtra Registration Number" value="' . htmlspecialchars($row['project_reg_number']) . '">
															    </div>
															</div>';
															echo '<div class="form-group row">
															    <label class="col-lg-2 col-form-label">QR Code upload (Optional)</label>
															    <div class="col-lg-9">
															        <input type="file" class="form-control" name="qr_code" placeholder="Enter Maharashtra Registration Number">

															    
															';
															echo '<img src="property/' . htmlspecialchars($row['qr_code']) . '" alt="pimage" height="150" width="180"></div></div>';
															 }
														}
													}
												?>
												 
											 
												
												<div class="form-group row">
													<label class="col-lg-2 col-form-label">Property Description</label>
													<div class="col-lg-9">
														<textarea class="tinymce form-control" name="content" rows="10" cols="30">
															<?php echo $row['pcontent']; ?>
														</textarea>
													</div>
												</div>
												
											</div>
											<div class="col-xl-6">
												<div class="form-group row">
													<label class="col-lg-3 col-form-label">Property Type</label>
													<div class="col-lg-9">
														<select class="form-control" required name="ptype" id="propertyType" onchange="showSelectedValue()">
													    <option selected value="<?php echo $row['type'] ?>"><?php echo $row['type']; ?></option>
													     <optgroup label="Residential">
														    <option value="apartment">Apartment</option>
														    <option value="bungalow">Bungalow</option>
														    <option value="flat">Flats</option>
														    <option value="ghar">Ghar</option>
														    <option value="land">Land</option>
														    <option value="pent-house">Pent House</option>
														    <option value="plots">Plots</option>
														    <option value="row-house">Row House</option>
														    <option value="second-home">Second Home</option>
														    <option value="terrace-flat">Terrace Flat</option>
														    <option value="villa">Villa</option>
														</optgroup>
														<optgroup label="Commercial">
													        <option value="offices">Offices</option>
													        <option value="plots">Plots</option>
													        <option value="shops">Shops</option>
													        <option value="space">Space</option>
													    </optgroup>
													    <optgroup label="Agriculture">
													        <option value="farm-house">Farm House</option>
													        <option value="land" >Land</option>
													    </optgroup>
													    
													   <optgroup label="Industrial">
													    <option value="company">Company</option>
													    <option value="factory">Factory</option>
													    <option value="godown">Godown</option>
													    <option value="industrial-land">Industrial Land</option>
													    <option value="land">Land</option>
													    <option value="midc">MIDC</option>
													    <option value="na-plots">N.A. Plots</option>
													    <option value="premises">Premises</option>
													    <option value="shed">Shed</option>
													    <option value="ware-house">Ware House</option>
													</optgroup>

													   
													</select>

													</div>
												</div>
												<div id="selling_type"  class="form-group row">
													<label class="col-lg-3 col-form-label">Selling Type</label>
													<div class="col-lg-9">
														<select class="form-control"  name="stype">
															 <option  selected value="<?php echo $row['stype'] ?>"><?php echo $row['stype']; ?></option>
														 
															<option value="new">New</option>
															<option value="rent">Rental</option>
														 	<option value="re-sale">Re-Sale</option>
                    										<option value="sale">Sale</option>
                    										<option value="buy">Buy</option>
														</select>
													</div>
												</div>
												<div id="selling_type"  class="form-group row">
													<label class="col-lg-3 col-form-label">Facing</label>
													<div class="col-lg-9">
														<select class="form-control"  required name="faceing">
															 <option selected value="<?php echo $row['faceing'] ?>"><?php echo $row['faceing']; ?></option>
															<option value="East">East</option>
															<option value="West">West</option>
															<option value="South">South</option>
															<option value="North">North</option>
															 <option value="Northeast">Northeast</option>
													        <option value="Southeast">Southeast</option>
													        <option value="Southwest">Southwest</option>
													        <option value="Northwest">Northwest</option>
														</select>
													</div>
												</div>
												<div id="bathroom" class="form-group row">
													<label class="col-lg-3 col-form-label">Bathroom</label>
													<div class="col-lg-9">
														<input type="text" class="form-control" name="bath"  placeholder="Enter Bathroom (only no 1 to 10)"  value="<?php echo $row['bathroom']; ?>">
													</div>
												</div>
												<div id="kitchen" class="form-group row">
													<label class="col-lg-3 col-form-label">Kitchen</label>
													<div class="col-lg-9">
														<input type="text" class="form-control" name="kitc"  placeholder="Enter Kitchen (only no 1 to 10)" value="<?php echo $row['kitchen']; ?>">
													</div>
												</div>
												
											</div>   
											<div id="bhk_bedroom_balcony_hall" class="col-xl-6">
												<div class="form-group row mb-3">
													<label class="col-lg-3 col-form-label">BHK</label>
													<div class="col-lg-9">
														<select selected class="form-control"  name="bhk">
															 <option value="<?php echo $row['bhk'] ?>"><?php echo $row['bhk']; ?></option>
															<option value="1 BHK">1 BHK</option>
															<option value="2 BHK">2 BHK</option>
															<option value="3 BHK">3 BHK</option>
															<option value="4 BHK">4 BHK</option>
															<option value="5 BHK">5 BHK</option>
															<option value="1,2 BHK">1,2 BHK</option>
															<option value="2,3 BHK">2,3 BHK</option>
															<option value="2,3,4 BHK">2,3,4 BHK</option>
														</select>
													</div>
												</div>
												<div class="form-group row">
													<label class="col-lg-3 col-form-label">Bedroom</label>
													<div class="col-lg-9">
														<input type="text" class="form-control" name="bed"  placeholder="Enter Bedroom  (only no 1 to 10)" value="<?php echo $row['bedroom']; ?>">
													</div>
												</div>
												<div class="form-group row">
													<label class="col-lg-3 col-form-label">Balcony</label>
													<div class="col-lg-9">
														<input type="text" class="form-control" name="balc"  placeholder="Enter Balcony  (only no 1 to 10)" value="<?php echo $row['balcony']; ?>">
													</div>
												</div>
												<div class="form-group row">
													<label class="col-lg-3 col-form-label">Hall</label>
													<div class="col-lg-9">
														<input type="text" class="form-control" name="hall"  placeholder="Enter Hall  (only no 1 to 10)" value="<?php echo $row['hall']; ?>">
													</div>
												</div>
												
											</div>

										</div>
									 <div class="row" id="area_unit">
											<div class="col-xl-12">
												<div class="form-group row">
													<label class="col-lg-2 col-form-label">Enter Area</label>
													<div class="col-lg-3">
														<input type="text" class="form-control" name="land_plot_area"  placeholder="Enter Area" value="<?php echo $row['land_plot_area']; ?>">
													</div>
												<label class="col-lg-2 col-form-label">Select  Select Area</label>
													<div class="col-lg-3">
															<select class="form-control"  name="type_area">
															 <option selected value="<?php echo $row['type_area'] ?>"><?php echo $row['type_area']; ?></option>	
														  <option value="sqYard">Square Yard (sq yard)</option>
											        <option value="sqMeter">Square Meter (sq meter)</option>
											        <option value="guntha">Guntha</option>
											        <option value="acre">Acre</option>
											        <option value="hectare">Hectare</option>
														</select>
													</div>
										</div>
									</div>
								</div>
										<h4 class="card-title">Price & Location</h4>
										<div class="row">
											<div class="col-xl-6">
												<div class="form-group row" id="select_floor">
													<label class="col-lg-3 col-form-label">Floor</label>
													<div class="col-lg-9">
														 
														<input type="number" class="form-control" name="floor"   value="<?php echo $row['floor'] ?>" placeholder="Enter Floor">
													</div>
												</div>
												<div class="form-group row">
													<label class="col-lg-3 col-form-label">Price</label>
													<div class="col-lg-9">
														<input type="text" class="form-control" name="price" required placeholder="Enter Price" value="<?php echo $row['price']; ?>">
													</div>
												</div>
												<div class="form-group row">
													<label class="col-lg-3 col-form-label">City</label>
													<div class="col-lg-9">
														<input type="text" class="form-control" name="city" required placeholder="Enter City"  value="<?php echo $row['city']; ?>">
													</div>
												</div>
												<div class="form-group row">
													<label class="col-lg-3 col-form-label">State</label>
													<div class="col-lg-9">
														<input type="text" class="form-control" name="state" required placeholder="Enter State"  value="<?php echo $row['state']; ?>">
													</div>
												</div>
											</div>
											<div class="col-xl-6">
												<div class="form-group row " id="select_total_floor">
													<label class="col-lg-3 col-form-label">Total Floor</label>
													<div class="col-lg-9">
														 	<input type="number" class="form-control" name="totalfl"    placeholder="Enter Total Floor" value="<?php echo $row['totalfloor']; ?>">
													</div>
												</div>
												<div class="form-group row">
													<label class="col-lg-3 col-form-label">Area Size</label>
													<div class="col-lg-9">
														<input type="text" class="form-control" name="asize" required placeholder="Enter Area Size (in Sq.Ft.)" value="<?php echo $row['size']; ?>">
													</div>
												</div>
												<div class="form-group row">
													<label class="col-lg-3 col-form-label">Address</label>
													<div class="col-lg-9">
														<input type="text" class="form-control" name="loc" required placeholder="Enter Address" value="<?php echo $row['location']; ?>">
													</div>
												</div>
												
											</div>
										</div>
										
										<div class="form-group row">
											<label class="col-lg-2 col-form-label">Add Amenities (Optional)</label>
											<div class="col-lg-9">
											
											
											<textarea class="tinymce form-control" name="feature" rows="10" cols="30">
												 
												 <?php echo $row['feature']; ?>
											</textarea>
											</div>
										</div>
												
										<h4 class="card-title">Image & Status</h4>
											<p class="text-danger">(the image must be 400 pixels wide and 250  pixels tall)</p>
										<div class="row">
											<div class="col-xl-6">
												
												<div class="form-group row">
													<label class="col-lg-3 col-form-label">Image</label>
													<div class="col-lg-9">
														<input class="form-control" name="aimage" type="file" >
														<img src="property/<?php echo $row['pimage'];?>" alt="pimage" height="150" width="180">
													</div>
												</div>
												<div class="form-group row">
													<label class="col-lg-3 col-form-label">Image 2</label>
													<div class="col-lg-9">
														<input class="form-control" name="aimage2" type="file"  >
														<img src="property/<?php echo $row['pimage2'];?>" alt="pimage" height="150" width="180">
													</div>
												</div>
												<div class="form-group row">
													<label class="col-lg-3 col-form-label">Image 4</label>
													<div class="col-lg-9">
														<input class="form-control" name="aimage4" type="file"  >
														<img src="property/<?php echo $row['pimage4'];?>" alt="pimage" height="150" width="180">
													</div>
												</div>
												<div class="form-group row">
													<label class="col-lg-3 col-form-label">Status</label>
													<div class="col-lg-9">
														<select class="form-control"    name="status" required>
															<option value="">Select Status</option>
															<option value="available">Available</option>
															<option value="sold out">Sold Out</option>
														</select>
													</div>
												</div>
												<div class="form-group row" id="basement_plan">
													<label class="col-lg-3 col-form-label">Basement Floor Plan Image</label>
													<div class="col-lg-9">
														<input class="form-control" name="fimage1" type="file">
														<img src="property/<?php echo $row['topmapimage'];?>" alt="pimage" height="150" width="180">
													</div>
												</div>
											</div>
											<div class="col-xl-6">
												
												<div class="form-group row">
													<label class="col-lg-3 col-form-label">Image 1</label>
													<div class="col-lg-9">
														<input class="form-control" name="aimage1" type="file" >
														<img src="property/<?php echo $row['pimage1'];?>" alt="pimage" height="150" width="180">
													</div>
												</div>
												<div class="form-group row">
													<label class="col-lg-3 col-form-label">image 3</label>
													<div class="col-lg-9">
														<input class="form-control" name="aimage3" type="file"  >
														<img src="property/<?php echo $row['pimage3'];?>" alt="pimage" height="150" width="180">
													</div>
												</div>
												<div class="form-group row">
													<label class="col-lg-3 col-form-label">Uid</label>
													<div class="col-lg-9">
														<input type="text" class="form-control" name="uid"  placeholder="Enter User Id (only number)">
													</div>
												</div>
												<div class="form-group row" id="floor_plan">
													<label class="col-lg-3 col-form-label">Floor Plan Image</label>
													<div class="col-lg-9">
														<input class="form-control" name="fimage" type="file">
														<img src="property/<?php echo $row['mapimage'];?>" alt="pimage" height="150" width="180">
													</div>
												</div>
												<div class="form-group row" id="ground_floor">
													<label class="col-lg-3 col-form-label">Ground Floor Plan Image</label>
													<div class="col-lg-9">
														<input class="form-control" name="fimage2" type="file">
														<img src="property/<?php echo $row['groundmapimage'];?>" alt="pimage" height="150" width="180">
													</div>
												</div>
											</div>
										</div>

										<hr>

										<div class="row">
											<div class="col-md-6">
												<div class="form-group row">
													<label class="col-lg-3 col-form-label"><b>Is Featured?</b></label>
													<div class="col-lg-9">
														<select class="form-control"  required name="isFeatured">
															 
															<option value="0">No</option>
															<option value="1">Yes</option>
														</select>
													</div>
												</div>
											</div>
										</div>

									 
										<div class="row">
											<div class="col-md-6">
												<div class="form-group row">
													<label class="col-lg-3 col-form-label"><b>Youtube Video </b></label>
													<div class="col-lg-9">
														<textarea name="youtube_code" style="width:100%">
															<?php echo $row['youtube_code']; ?>
														</textarea>
														 
													</div>
												</div>
											</div>
										</div>


										
											<input type="submit" value="Submit" class="btn btn-primary"name="add" style="margin-left:200px;">
										
								</div>
								</form>

								<?php
									} 
								?>	
							</div>
						</div>
					</div>
				
				</div>			
			</div>
			<!-- /Main Wrapper -->

		
		<!-- jQuery -->
        <script src="assets/js/jquery-3.2.1.min.js"></script>
		<script src="assets/plugins/tinymce/tinymce.min.js"></script>
		<script src="assets/plugins/tinymce/init-tinymce.min.js"></script>
		<!-- Bootstrap Core JS -->
        <script src="assets/js/popper.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
		
		<!-- Slimscroll JS -->
        <script src="assets/plugins/slimscroll/jquery.slimscroll.min.js"></script>
		
			<script  src="assets/js/script.js"></script>
		<script type="text/javascript">
			window.addEventListener("load", (event) => {
			 document.getElementById('area_unit').style.display='none';
			});

			  function showSelectedValue() {
            var selectElement = document.getElementById("propertyType");
            var selectedValue = selectElement.options[selectElement.selectedIndex].value;
           	if(selectedValue=='plots'){
           		// alert(selectedValue);
           		document.getElementById('bhk_bedroom_balcony_hall').style.display='none';
           		document.getElementById('kitchen').style.display='none';
           		document.getElementById('bathroom').style.display='none';
           		// document.getElementById('selling_type').style.display='bl';
           		document.getElementById('select_floor').style.display='none';
           		document.getElementById('select_total_floor').style.display='none';
           		document.getElementById('ground_floor').style.display='none';
           		document.getElementById('basement_plan').style.display='none';
           		document.getElementById('floor_plan').style.display='none';
           		document.getElementById('area_unit').style.display='block';
           	}
           	else if(selectedValue=='land'){
           		document.getElementById('bhk_bedroom_balcony_hall').style.display='none';
           		document.getElementById('kitchen').style.display='none';
           		document.getElementById('bathroom').style.display='none';
           		// document.getElementById('selling_type').style.display='none';
           		document.getElementById('select_floor').style.display='none';
           		document.getElementById('select_total_floor').style.display='none';
           		document.getElementById('ground_floor').style.display='none';
           		document.getElementById('basement_plan').style.display='none';
           		document.getElementById('floor_plan').style.display='none';
           	   document.getElementById('area_unit').style.display='block';
           	}
           		else if(selectedValue=='na-plots'){
           		document.getElementById('bhk_bedroom_balcony_hall').style.display='none';
           		document.getElementById('kitchen').style.display='none';
           		document.getElementById('bathroom').style.display='none';
           		// document.getElementById('selling_type').style.display='none';
           		document.getElementById('select_floor').style.display='none';
           		document.getElementById('select_total_floor').style.display='none';
           		document.getElementById('ground_floor').style.display='none';
           		document.getElementById('basement_plan').style.display='none';
           		document.getElementById('floor_plan').style.display='none';
           	   document.getElementById('area_unit').style.display='block';
           	}
           	else{
           		
           		document.getElementById('kitchen').removeAttribute("style");
           		document.getElementById('bathroom').removeAttribute("style");
           		document.getElementById('selling_type').removeAttribute("style");
           		document.getElementById('bhk_bedroom_balcony_hall').removeAttribute("style");
           		document.getElementById('area_unit').style.display='none';
           		document.getElementById('select_floor').removeAttribute("style");
           		document.getElementById('select_total_floor').removeAttribute("style");
           		document.getElementById('floor_plan').removeAttribute("style");
           		document.getElementById('basement_plan').removeAttribute("style");
           		document.getElementById('ground_floor').removeAttribute("style");

           	}

        }
        // Wait for the DOM to be fully loaded before running the JavaScript code
document.addEventListener("DOMContentLoaded", function () {
    // Get a reference to the <select> element
    var selectElement = document.getElementById("propertyType");

    // Get the <p> element where you want to display the selected value
    

    // Get the selected value and display it
    var selectedValue = selectElement.value;
     	if(selectedValue=='plots'){
           		// alert(selectedValue);
           		document.getElementById('bhk_bedroom_balcony_hall').style.display='none';
           		document.getElementById('kitchen').style.display='none';
           		document.getElementById('bathroom').style.display='none';
           		// document.getElementById('selling_type').style.display='bl';
           		document.getElementById('select_floor').style.display='none';
           		document.getElementById('select_total_floor').style.display='none';
           		document.getElementById('ground_floor').style.display='none';
           		document.getElementById('basement_plan').style.display='none';
           		document.getElementById('floor_plan').style.display='none';
           		document.getElementById('area_unit').style.display='block';
           	}
           	else if(selectedValue=='land'){
           		document.getElementById('bhk_bedroom_balcony_hall').style.display='none';
           		document.getElementById('kitchen').style.display='none';
           		document.getElementById('bathroom').style.display='none';
           		// document.getElementById('selling_type').style.display='none';
           		document.getElementById('select_floor').style.display='none';
           		document.getElementById('select_total_floor').style.display='none';
           		document.getElementById('ground_floor').style.display='none';
           		document.getElementById('basement_plan').style.display='none';
           		document.getElementById('floor_plan').style.display='none';
           	   document.getElementById('area_unit').style.display='block';
           	}
           		else if(selectedValue=='na-plots'){
           		document.getElementById('bhk_bedroom_balcony_hall').style.display='none';
           		document.getElementById('kitchen').style.display='none';
           		document.getElementById('bathroom').style.display='none';
           		// document.getElementById('selling_type').style.display='none';
           		document.getElementById('select_floor').style.display='none';
           		document.getElementById('select_total_floor').style.display='none';
           		document.getElementById('ground_floor').style.display='none';
           		document.getElementById('basement_plan').style.display='none';
           		document.getElementById('floor_plan').style.display='none';
           	   document.getElementById('area_unit').style.display='block';
           	}
           	else{
           		
           		document.getElementById('kitchen').removeAttribute("style");
           		document.getElementById('bathroom').removeAttribute("style");
           		document.getElementById('selling_type').removeAttribute("style");
           		document.getElementById('bhk_bedroom_balcony_hall').removeAttribute("style");
           		document.getElementById('area_unit').style.display='none';
           		document.getElementById('select_floor').removeAttribute("style");
           		document.getElementById('select_total_floor').removeAttribute("style");
           		document.getElementById('floor_plan').removeAttribute("style");
           		document.getElementById('basement_plan').removeAttribute("style");
           		document.getElementById('ground_floor').removeAttribute("style");

           	}

    
});

		</script>
		
    </body>

</html>