<?php
include("config.php");
$fid = $_GET['id'];
$sql = "DELETE FROM inquiry WHERE id = {$fid}";
$result = mysqli_query($con, $sql);
if($result == true)
{
	$msg="<p class='alert alert-success'>Feedback Deleted</p>";
	header("Location:inquiry.php?msg=$msg");
}
else{
	$msg="<p class='alert alert-warning'>Feedback Not Deleted</p>";
	header("Location:inquiry.php?msg=$msg");
}
mysqli_close($con);
?>
