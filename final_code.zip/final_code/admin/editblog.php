<?php
session_start();
require("config.php");

if (!isset($_SESSION['auser'])) {
    header("location:index.php");
}

$msg = "";

if (isset($_GET['id'])) {
    $uid = $_GET['id'];

    // Fetch the blog post from the database
    $stmt = mysqli_prepare($con, "SELECT * FROM blogs WHERE id = ?");
    mysqli_stmt_bind_param($stmt, "i", $uid);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if ($row = mysqli_fetch_assoc($result)) {
        $blogPost = $row;
    } else {
        $msg = "<p class='alert alert-warning'>Blog not found</p>";
    }

    mysqli_stmt_close($stmt);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = $_POST["title"];
    $author = $_POST["author"];
    $category = $_POST["category"];
    $description = $_POST["description"];
    $content = $_POST["content"]; // Added content field

    // Handle image upload
    $image = $blogPost['aimage']; // Default to the current image

    if (isset($_FILES['new_image']) && $_FILES['new_image']['error'] === 0) {
        // Check if a new image was uploaded
        $image_tmp = $_FILES['new_image']['tmp_name'];
        $image_name = $_FILES['new_image']['name'];
        $image_extension = pathinfo($image_name, PATHINFO_EXTENSION);
        $image = uniqid() . '.' . $image_extension;

        move_uploaded_file($image_tmp, "../contentblog/" . $image);
    }

    // Update the blog post in the database
    $stmt = mysqli_prepare($con, "UPDATE blogs SET title = ?, author = ?, category = ?, description = ?, content = ?, aimage = ? WHERE id = ?");
    mysqli_stmt_bind_param($stmt, "ssssssi", $title, $author, $category, $description, $content, $image, $uid);

    if (mysqli_stmt_execute($stmt)) {
        header('location:?id='.$_GET['id'].'&msg=<p class="alert alert-success">Blog Updated</p>');
       
    } else {
          header('location:?id='.$_GET['id'].'&msg=<p class="alert alert-danger">Blog Not Updated</p>');
    }

    mysqli_stmt_close($stmt);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
    <title>Edit Blogs</title>
    
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.png">
    
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    
    <!-- Fontawesome CSS -->
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">
    
    <!-- Feathericon CSS -->
    <link rel="stylesheet" href="assets/css/feathericon.min.css">
    
    <!-- Datatables CSS -->
    <link rel="stylesheet" href="assets/plugins/datatables/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="assets/plugins/datatables/responsive.bootstrap4.min.css">
    <link rel="stylesheet" href="assets/plugins/datatables/select.bootstrap4.min.css">
    <link rel="stylesheet" href="assets/plugins/datatables/buttons.bootstrap4.min.css">
    
    <!-- Main CSS -->
    <link rel="stylesheet" href="assets/css/style.css">
    
    <!--[if lt IE 9]>
        <script src="assets/js/html5shiv.min.js"></script>
        <script src="assets/js/respond.min.js"></script>
    <![endif]-->
</head>
<body>
    <!-- Main Wrapper -->
    <!-- Header -->
    <?php include("header.php"); ?>
    <!-- /Header -->

    <!-- Page Wrapper -->
    <div class="page-wrapper">
        <div class="content container-fluid">
            <!-- Page Header -->
            <div class="page-header">
                <div class="row">
                    <div class="col">
                        <h3 class="page-title">Blogs</h3>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="dashboard.php">Dashboard</a></li>
                            <li class="breadcrumb-item active">Edit Blog Post</li>
                        </ul>
                    </div>
                </div>
            </div>
            <!-- /Page Header -->
            
            <div class="row">
                <div class="col-sm-12">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title">Edit Blog Post</h4>
                            <?php 
                                echo $_GET['msg'];
                            ?>
                        </div>
                        <div class="card-body">
                            <form method="POST" action="" enctype="multipart/form-data">
                                <div class="form-group">
                                    <label for="title">Title:</label>
                                    <input type="text" name="title" class="form-control" value="<?php echo $blogPost['title']; ?>">
                                </div>
                                <div class="form-group">
                                    <label for="author">Author:</label>
                                    <input type="text" name="author" class="form-control" value="<?php echo $blogPost['author']; ?>">
                                </div>
                                <div class="form-group">
                                    <label for="category">Category:</label>
                                    <input type="text" name="category" class="form-control" value="<?php echo $blogPost['category']; ?>">
                                </div>
                                <div class="form-group">
                                    <label for="description">Description:</label>
                                    <textarea name="description" class="form-control"><?php echo $blogPost['description']; ?></textarea>
                                </div>
                                <div class="form-group">
                                    <label for="content">Content:</label>
                                   <textarea class="tinymce form-control" name="content" rows="10" cols="30"><?php echo $blogPost['content']; ?></textarea>
                                </div>
                                <div class="form-group">
                                    <label for="new_image">New Image:</label>
                                    <input type="file" name="new_image" class="form-control">
                                </div>
                                <div class="form-group">
                                    <label>Current Image:</label>
                                    <img src="../contentblog/<?php echo $blogPost['aimage']; ?>" height="50px" width="50px">
                                </div>
                                <input type="submit" value="Update Blog" class="btn btn-primary">
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- /Main Wrapper -->

    <!-- jQuery -->
    <script src="assets/js/jquery-3.2.1.min.js"></script>
    
    <!-- Bootstrap Core JS -->
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    
    <!-- Slimscroll JS -->
    <script src="assets/plugins/slimscroll/jquery.slimscroll.min.js"></script>
    
    <!-- Datatables JS -->
    <script src="assets/plugins/datatables/jquery.dataTables.min.js"></script>
    <script src="assets/plugins/datatables/dataTables.bootstrap4.min.js"></script>
    <script src="assets/plugins/datatables/dataTables.responsive.min.js"></script>
    <script src="assets/plugins/datatables/responsive.bootstrap4.min.js"></script>
    
    <script src="assets/plugins/datatables/dataTables.select.min.js"></script>
    
    <script src="assets/plugins/datatables/dataTables.buttons.min.js"></script>
    <script src="assets/plugins/datatables/buttons.bootstrap4.min.js"></script>
    <script src="assets/plugins/datatables/buttons.html5.min.js"></script>
    <script src="assets/plugins/datatables/buttons.flash.min.js"></script>
    <script src="assets/plugins/datatables/buttons.print.min.js"></script>
    <script src="assets/plugins/tinymce/tinymce.min.js"></script>
        <script src="assets/plugins/tinymce/init-tinymce.min.js"></script>
    <!-- Custom JS -->
    <script src="assets/js/script.js"></script>
</body>
</html>
