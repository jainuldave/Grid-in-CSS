<?php
session_start();
require("config.php");
////code
 
if(!isset($_SESSION['auser']))
{
	header("location:index.php");
}
?>  
<!-- Mobile Sidebar CSS -->
    <style>
        /* Mobile Sidebar CSS */
        .mobile-sidebar {
            position: fixed;
            top: 0;
            left: -300px; /* Initially hidden to the left */
            width: 250px;
            height: 100%;
            background-color: #333;
            overflow-y: auto;
            transition: left 0.3s ease-in-out;
        }

        .mobile-sidebar ul {
            list-style: none;
            padding: 0;
        }

        .mobile-sidebar li {
            padding: 15px;
        }

        .mobile-sidebar a {
            color: #fff;
            text-decoration: none;
        }

        .close-btn {
            position: absolute;
            top: 15px;
            right: 15px;
            cursor: pointer;
            color: #fff;
            font-size: 24px;
        }
        /* /Mobile Sidebar CSS */
    </style>
  <div class="header " style="background-color:#004274">
			
				<!-- Logo -->
                <div class="header-left " >
                    <a href="dashboard.php" class="logo">
					<img class="nav-logo" src="../images/logo/Property Maharashtra Website Logo White.png" alt="" style="height: 56px;width: 110px;">
					</a>
					<a href="dashboard.php" class="logo logo-small">
						<img src="../images/logo/Property Maharashtra Website Logo White.png" alt="Logo" width="30" height="30">
					</a>
                </div>
				<!-- /Logo -->
				
				<a href="javascript:void(0);" id="toggle_btn">
					<i class="fe fe-text-align-left"></i>
				</a>
				

				
				<!-- Mobile Menu Toggle -->
				<a class="mobile_btn" id="mobile_btn" data-toggle="modal" data-target="#mobileMenuModal">
    <i class="fa fa-bars"></i>
</a>
				<!-- /Mobile Menu Toggle -->
				
				<!-- Header Right Menu -->
				<ul class="nav user-menu">

					
					<!-- User Menu -->
					<!-- <h4 style="color:white;margin-top:13px;text-transform:capitalize;"><?php echo $_SESSION['auser'];?></h4> -->
					<li class="nav-item dropdown app-dropdown">
						<a href="#" class="dropdown-toggle nav-link" data-toggle="dropdown">
							<span class="user-img"><img class="rounded-circle" src="assets/img/profiles/avatar-01.png" width="31" alt="Ryan Taylor"></span>
						</a>
						
						<div class="dropdown-menu">
							<div class="user-header">
								<div class="avatar avatar-sm">
									<img src="assets/img/profiles/avatar-01.png" alt="User Image" class="avatar-img rounded-circle">
								</div>
								<div class="user-text">
									<h6><?php echo $_SESSION['auser'];?></h6>
									<p class="text-muted mb-0">Administrator</p>
								</div>
							</div>
							<a class="dropdown-item" href="profile.php">Profile</a>
							<a class="dropdown-item" href="logout.php">Logout</a>
						</div>
					</li>

					<!-- /User Menu -->
					
				</ul>
				<!-- /Header Right Menu -->
				
            </div>
			<br><br>
			<!-- header --->
			
			
			
						<!-- Sidebar -->
            <div class="sidebar" id="sidebar" >
                <div class="sidebar-inner slimscroll">
					<div id="sidebar-menu" class="sidebar-menu">
						<ul>
							<li class="menu-title"> 
								<span>Main</span>
							</li>
							<li> 
								<a href="dashboard.php"><i class="fe fe-home"></i> <span>Dashboard</span></a>
							</li>
								<li class="menu-title"> 
								<span>Leads</span>
							</li>
							<li> 
								<a href="leads.php"><i class="fa fa-bolt" aria-hidden="true"></i>
 <span>Leads</span></a>
							</li>
							
							<!-- <li class="menu-title"> 
								<span>Authentication</span>
							</li>
						
							<li class="submenu">
								<a href="#"><i class="fe fe-user"></i> <span> Authentication </span> <span class="menu-arrow"></span></a>
								<ul style="display: none;">
									<li><a href="index.php"> Login </a></li>
									<li><a href="register.php"> Register </a></li>
									
								</ul>
							</li> -->
							<li class="menu-title"> 
								<span>All Users</span>
							</li>
						
							<li class="submenu">
								<a href="#"><i class="fe fe-user"></i> <span> All Users </span> <span class="menu-arrow"></span></a>
								<ul style="display: none;">
									<li><a href="adminlist.php"> Admin </a></li>
									<li><a href="userlist.php?type=owner"> Owner </a></li>
										<li><a href="userlist.php?type=builder/developer"> Builder/Developer </a></li>
									<li><a href="userlist.php?type=agent"> Agent </a></li>
								<li><a href="userlist.php?type=channel partner"> Channel partner </a></li>
									<li><a href="userlist.php?type=strategic partner"> Strategic Partner  </a></li>
								 
								</ul>
							</li>

							<li class="menu-title"> 
								<span>State & City</span>
							</li>
						
							<li class="submenu">
								<a href="#"><i class="fe fe-location"></i> <span>State & City</span> <span class="menu-arrow"></span></a>
								<ul style="display: none;">
									<li><a href="stateadd.php"> State </a></li>
									<li><a href="cityadd.php"> City </a></li>
								</ul>
							</li>
						
							<li class="menu-title"> 
								<span>Property Management</span>
							</li>
							<li class="submenu">
								<a href="#"><i class="fe fe-map"></i> <span> Property</span> <span class="menu-arrow"></span></a>
								<ul style="display: none;">
									<li><a href="propertyadd.php"> Add Property</a></li>
									<li><a href="propertyview.php"> View Property </a></li>
									
								</ul>
							</li>
							
								<li class="menu-title"> 
								<span>Blog Management</span>
							</li>
							<li class="submenu">
								<a href="#"><i class="fe fe-edit"></i><span> Blogs</span> <span class="menu-arrow"></span></a>
								<ul style="display: none;">
									<li><a href="addblog.php"> Add Blog</a></li>
									<li><a href="viewblog.php"> View Blog </a></li>
									
								</ul>
							</li>
							
							
						
						
								<li class="menu-title"> 
								<span>Query</span>
							</li>
							<li class="submenu">
								<a href="#"><i class="fe fe-comment"></i> <span> Contact,Feedback </span> <span class="menu-arrow"></span></a>
								<ul style="display: none;">
									<li><a href="contactview.php"> Contact </a></li>
									<li><a href="feedbackview.php"> Feedback </a></li>
									<li><a href="inquiry.php"> Inquiry </a></li>
								
								</ul>
							</li>
							<!-- <li class="menu-title"> 
								<span>About</span>
							</li>
							<li class="submenu">
								<a href="#"><i class="fe fe-browser"></i> <span> About Page </span> <span class="menu-arrow"></span></a>
								<ul style="display: none;">
									<li><a href="aboutadd.php"> Add About Content </a></li>
									<li><a href="aboutview.php"> View About </a></li>
								</ul>
							</li>
							 -->
						</ul>
					</div>
                </div>
            </div>
			<!-- /Sidebar --><!-- Trigger Button for the Bootstrap Modal -->
 <!-- Trigger Button for the Bootstrap Modal -->
<a class="mobile_btn" id="mobile_btn" data-toggle="modal" data-target="#mobileMenuModal">
    <i class="fa fa-bars"></i>
</a>

<!-- Bootstrap Modal for Mobile Menu -->
<div class="modal fade" id="mobileMenuModal" tabindex="-1" role="dialog" aria-labelledby="mobileMenuModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document" >
        <div class="modal-content " >
            <div class="modal-header">
                <h5 class="modal-title" id="mobileMenuModalLabel"> Menu</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body" > 
                <!-- Accordion-Style Mobile Menu Content -->
                <div id="mobileMenuAccordion">
                    <!-- Dashboard -->
                    <div class="card">
                        <div class="card-header" id="headingDashboard">
                            <h5 class="mb-0">
                                <button class="btn btn-link text-dark" data-toggle="collapse" data-target="#collapseDashboard" aria-expanded="true" aria-controls="collapseDashboard">
                                    Dashboard
                                </button>
                            </h5>
                        </div>
                          <!-- About -->
                    <div class="card">
                        <div class="card-header" id="headingAbout1">
                            <h5 class="mb-0">
                                <button class="btn btn-link text-dark" data-toggle="collapse" data-target="#collapseAbout1" aria-expanded="false" aria-controls="collapseAbout1">
                                    Leads
                                </button>
                            </h5>
                        </div>

                        <div id="collapseAbout1" class="collapse" aria-labelledby="headingAbout1" data-parent="#mobileMenuAccordion">
                            <div class="card-body">
                            	<ul class="list-group text-dark">
					  <li class="list-group-item"> <a href="leads.php" class="text-dark">Leads</a></li>
					 

                               
                             
                            </ul>
                            </div>
                        </div>
                    </div>

                        <div id="collapseDashboard" class="collapse show" aria-labelledby="headingDashboard" data-parent="#mobileMenuAccordion">
                            <div class="card-body text-dark">
                                <a href="dashboard.php" class="text-dark">Dashboard</a>
                            </div>
                        </div>
                    </div>

                    <!-- All Users -->
                    <div class="card">
                        <div class="card-header" id="headingAllUsers">
                            <h5 class="mb-0">
                                <button class="btn btn-link text-dark" data-toggle="collapse" data-target="#collapseAllUsers" aria-expanded="false" aria-controls="collapseAllUsers">
                                    All Users
                                </button>
                            </h5>
                        </div>

                        <div id="collapseAllUsers" class="collapse" aria-labelledby="headingAllUsers" data-parent="#mobileMenuAccordion">
                            <div class="card-body">
                            	<ul class="list-group">
								  <li class="list-group-item "><a href="adminlist.php" class="text-dark">Admin</a></li>
								   <li class="list-group-item ">   <a href="userlist.php?type=owner" class="text-dark">Owner</a></li>

								   <li class="list-group-item "> <a href="userlist.php?type=agent" class="text-dark">Agent</a></li>
								   <li class="list-group-item "><a href="userlist.php?type=builder/developer" class="text-dark">Builder/Developer</a></li>
								   <li class="list-group-item "> 
                                <a href="userlist.php?type=channel partner" class="text-dark">Channel partner</a></li>
								  
								</ul>
                                 
                             
              
                               
                            </div>
                        </div>
                    </div>

                    <!-- State & City -->
                    <div class="card">
                        <div class="card-header" id="headingStateCity">
                            <h5 class="mb-0">
                                <button class="btn btn-link text-dark" data-toggle="collapse" data-target="#collapseStateCity" aria-expanded="false" aria-controls="collapseStateCity">
                                    State & City
                                </button>
                            </h5>
                        </div>

                        <div id="collapseStateCity" class="collapse" aria-labelledby="headingStateCity" data-parent="#mobileMenuAccordion">
                            <div class="card-body">
                            	<ul class="list-group">
  <li class="list-group-item"><a href="stateadd.php" class="text-dark">State</a></li>
  <li class="list-group-item">  <a href="cityadd.php" class="text-dark">City</a></li>

                                 
                             
                            </ul>
                            </div>
                        </div>
                    </div>

                    <!-- Property Management -->
                    <div class="card">
                        <div class="card-header" id="headingProperty">
                            <h5 class="mb-0">
                                <button class="btn btn-link text-dark" data-toggle="collapse" data-target="#collapseProperty" aria-expanded="false" aria-controls="collapseProperty">
                                    Property Management
                                </button>
                            </h5>
                        </div>

                        <div id="collapseProperty" class="collapse" aria-labelledby="headingProperty" data-parent="#mobileMenuAccordion">
                            <div class="card-body">
                            	<ul class="list-group">
                            		  <li class="list-group-item"> <a href="propertyadd.php" class="text-dark">Add Property</a></li>
                            		    <li class="list-group-item"> <a href="propertyview.php" class="text-dark">View Property</a></li>

                               
                               
                            </ul>
                            </div>
                        </div>
                    </div>

                    <!-- Blog Management -->
                    <div class="card">
                        <div class="card-header" id="headingBlog">
                            <h5 class="mb-0">
                                <button class="btn btn-link text-dark" data-toggle="collapse" data-target="#collapseBlog" aria-expanded="false" aria-controls="collapseBlog">
                                    Blog Management
                                </button>
                            </h5>
                        </div>

                        <div id="collapseBlog" class="collapse" aria-labelledby="headingBlog" data-parent="#mobileMenuAccordion">
                            <div class="card-body"><ul class="list-group">
                            	  <li class="list-group-item"><a href="addblog.php" class="text-dark">Add Blog</a></li>
  <li class="list-group-item">  <a href="viewblog.php" class="text-dark">View Blog</a></li>

                                
                              
                            </ul>
                            </div>
                        </div>
                    </div>

                    <!-- Query -->
                    <div class="card">
                        <div class="card-header" id="headingQuery">
                            <h5 class="mb-0">
                                <button class="btn btn-link text-dark" data-toggle="collapse" data-target="#collapseQuery" aria-expanded="false" aria-controls="collapseQuery">
                                    Query
                                </button>
                            </h5>
                        </div>

                        <div id="collapseQuery" class="collapse" aria-labelledby="headingQuery" data-parent="#mobileMenuAccordion">
                            <div class="card-body">
                            	<ul class="list-group">
                            		  <li class="list-group-item"> <a href="contactview.php" class="text-dark">Contact</a></li>
                            		   <li class="list-group-item">  <a href="feedbackview.php" class="text-dark">Feedback</a></li>
                            		    <li class="list-group-item"> <a href="inquiry.php" class="text-dark">Inquiry</a></li>


                               
                              
                               
                            </ul>
                            </div>
                        </div>

                    </div>

                    <!-- About -->
                   <!--  <div class="card">
                        <div class="card-header" id="headingAbout">
                            <h5 class="mb-0">
                                <button class="btn btn-link text-dark" data-toggle="collapse" data-target="#collapseAbout" aria-expanded="false" aria-controls="collapseAbout">
                                    About
                                </button>
                            </h5>
                        </div> -->

                   <!--      <div id="collapseAbout" class="collapse" aria-labelledby="headingAbout" data-parent="#mobileMenuAccordion">
                            <div class="card-body">
                            	<ul class="list-group text-dark">
					  <li class="list-group-item"> <a href="aboutadd.php" class="text-dark">Add About Content</a></li>
					  <li class="list-group-item">   <a href="aboutview.php" class="text-dark">View About</a></li>

                               
                             
                            </ul>
                            </div>
                        </div> -->
                    </div>
                </div>
                <!-- /Accordion-Style Mobile Menu Content -->
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<!-- /Bootstrap Modal -->


<script>
	$(document).ready(function () {
    // Show mobile sidebar when the mobile menu button is clicked
    $("#mobile_btn").click(function () {
        $("#mobileMenuModal").modal("show");
    });
});

</script>