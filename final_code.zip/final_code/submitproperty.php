<?php 
error_reporting(0);
ini_set('session.cache_limiter','public');
session_cache_limiter(false);
session_start();
include("config.php");
// Function to generate a random name for the image
function generateRandomName($fileExtension) {
    $characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    $randomString = '';
    $length = 10; // You can adjust the length of the random string as needed

    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, strlen($characters) - 1)];
    }

    return $randomString . '.' . $fileExtension;
}
if(!isset($_SESSION['uemail']))
{
	header("location:login.php");
}

//// code insert
//// add code
$error="";
$msg="";
if (isset($_POST['add'])) {
    $title = $_POST['title'];
    $project_reg_number = $_POST['project_reg_number']; //1
    $agent_reg_number = $_POST['agent_reg_number']; //2
    $content =  $_POST['content'];
    $ptype = $_POST['ptype'];
    $bhk = $_POST['bhk'];
    $bed = $_POST['bed'];
    $balc = $_POST['balc'];
    $hall = $_POST['hall'];
    $stype = $_POST['stype'];
    $bath = $_POST['bath'];
    $kitc = $_POST['kitc'];
    $floor = $_POST['floor'];
    $price = $_POST['price'];
    $city = $_POST['city'];
    $asize = $_POST['asize'];
    $loc = $_POST['loc'];
    $state = $_POST['state'];
    $status = $_POST['status'];
    $uid = $_SESSION['uid'];
    $feature =   $_POST['feature'];
    $youtube_code = $_POST['youtube_code'];
    $faceing = $_POST['faceing'];
    $type_area = $_POST['type_area'];
    $land_plot_area = $_POST['land_plot_area'];

    $totalfloor = $_POST['totalfl'];

    $aimage = $_FILES['aimage']['name'];
    $aimage1 = $_FILES['aimage1']['name'];
    $aimage2 = $_FILES['aimage2']['name'];
    $aimage3 = $_FILES['aimage3']['name'];
    $aimage4 = $_FILES['aimage4']['name'];

    $fimage = $_FILES['fimage']['name'];
    $fimage1 = $_FILES['fimage1']['name'];
    $fimage2 = $_FILES['fimage2']['name'];
    $qr_code_image  = $_FILES['qr_code']['name'];
    $isFeatured = 0;

    $temp_name = $_FILES['aimage']['tmp_name'];
    $temp_name1 = $_FILES['aimage1']['tmp_name'];
    $temp_name2 = $_FILES['aimage2']['tmp_name'];
    $temp_name3 = $_FILES['aimage3']['tmp_name'];
    $temp_name4 = $_FILES['aimage4']['tmp_name'];

    $temp_name5 = $_FILES['fimage']['tmp_name'];
    $temp_name6 = $_FILES['fimage1']['tmp_name'];
    $temp_name7 = $_FILES['fimage2']['tmp_name'];

    $temp_name_qr = $_FILES['qr_code']['tmp_name'];

    // Generate random names for the uploaded images
    $randomName1 = generateRandomName(pathinfo($aimage, PATHINFO_EXTENSION));
    $randomName2 = generateRandomName(pathinfo($aimage1, PATHINFO_EXTENSION));
    $randomName3 = generateRandomName(pathinfo($aimage2, PATHINFO_EXTENSION));
    $randomName4 = generateRandomName(pathinfo($aimage3, PATHINFO_EXTENSION));
    $randomName5 = generateRandomName(pathinfo($aimage4, PATHINFO_EXTENSION));
    $randomName6 = generateRandomName(pathinfo($fimage, PATHINFO_EXTENSION));
    $randomName7 = generateRandomName(pathinfo($fimage1, PATHINFO_EXTENSION));
    $randomName8 = generateRandomName(pathinfo($fimage2, PATHINFO_EXTENSION));
    $randomName9 = generateRandomName(pathinfo($qr_code_image, PATHINFO_EXTENSION));

    // Move uploaded files with random names
    move_uploaded_file($temp_name, "admin/property/$randomName1");
    move_uploaded_file($temp_name1, "admin/property/$randomName2");
    move_uploaded_file($temp_name2, "admin/property/$randomName3");
    move_uploaded_file($temp_name3, "admin/property/$randomName4");
    move_uploaded_file($temp_name4, "admin/property/$randomName5");
    move_uploaded_file($temp_name5, "admin/property/$randomName6");
    move_uploaded_file($temp_name6, "admin/property/$randomName7");
    move_uploaded_file($temp_name7, "admin/property/$randomName8");
    move_uploaded_file($temp_name_qr, "admin/property/$randomName9");

    // Update the variables with random names in the SQL query
    $aimage = $randomName1;
    $aimage1 = $randomName2;
    $aimage2 = $randomName3;
    $aimage3 = $randomName4;
    $aimage4 = $randomName5;
    
     if(empty($_FILES['qr_code']['tmp_name'])){
    	$qr_code_image = "";
     }
    else{
    	$qr_code_image = $randomName9;
    }
    //this is for the fimage
     if(empty($_FILES['fimage']['tmp_name'])){
    	$fimage = "";
    }
    else{
    	$fimage = $randomName6;
    }
    // //this is for the fimage1
    if(empty($_FILES['fimage1']['tmp_name'])){
    	$fimage1 = "";
    }
    else{
    	$fimage1 = $randomName7;
    }
    //this is for the fimage2
    if(empty($_FILES['fimage2']['tmp_name'])){
    	$fimage2 = "";
    }
    else{
    	$fimage2 = $randomName8;
    }


    // Insert the data into the database
    $sql = "INSERT INTO property (title,pcontent,type,bhk,stype,bedroom,bathroom,balcony,kitchen,hall,floor,size,price,location,city,state,feature,pimage,pimage1,pimage2,pimage3,pimage4,uid,status,mapimage,topmapimage,groundmapimage,totalfloor,isFeatured,youtube_code,post_status,project_reg_number,agent_reg_number,qr_code,faceing,land_plot_area,type_area)
    VALUES('$title','$content','$ptype','$bhk','$stype','$bed','$bath','$balc','$kitc','$hall','$floor','$asize','$price',
    '$loc','$city','$state','$feature','$aimage','$aimage1','$aimage2','$aimage3','$aimage4','$uid','$status','$fimage','$fimage1','$fimage2','$totalfloor','$isFeatured','$youtube_code','Pending','$project_reg_number','$agent_reg_number','$qr_code_image','$faceing','$land_plot_area','$type_area')";

    $result = mysqli_query($con, $sql);
    if ($result) {
        $msg = "<p class='alert alert-success'>Property Inserted Successfully</p>";
    } else {
        $error = "<p class='alert alert-warning'>Something went wrong. Please try again</p>";
    }
}	
?>
<!DOCTYPE html>
<html lang="en">

<head>
<!-- Required meta tags -->
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<!-- Meta Tags -->
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<link rel="shortcut icon" href="images/favicon.ico">

<!--	Fonts
	========================================================-->
<link href="https://fonts.googleapis.com/css?family=Muli:400,400i,500,600,700&amp;display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Comfortaa:400,700" rel="stylesheet">

<!--	Css Link
	========================================================-->
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="css/bootstrap-slider.css">
<link rel="stylesheet" type="text/css" href="css/jquery-ui.css">
<link rel="stylesheet" type="text/css" href="css/layerslider.css">
<link rel="stylesheet" type="text/css" href="css/color.css">
<link rel="stylesheet" type="text/css" href="css/owl.carousel.min.css">
<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="fonts/flaticon/flaticon.css">
<link rel="stylesheet" type="text/css" href="css/style.css">
<link rel="stylesheet" type="text/css" href="css/login.css">

<!--	Title
	=========================================================-->
<title>Submit Property</title>
</head>
<body>

<!--	Page Loader
=============================================================
<div class="page-loader position-fixed z-index-9999 w-100 bg-white vh-100">
	<div class="d-flex justify-content-center y-middle position-relative">
	  <div class="spinner-border" role="status">
		<span class="sr-only">Loading...</span>
	  </div>
	</div>
</div>
--> 


<div id="page-wrapper">
    <div class="row"> 
        <!--	Header start  -->
		<?php include("include/header.php");?>
        <!--	Header end  -->
        
        <!--	Banner   --->
        <!-- <div class="banner-full-row page-banner" style="background-image:url('images/breadcromb.jpg');">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <h2 class="page-name float-left text-white text-uppercase mt-1 mb-0"><b>Submit Property</b></h2>
                    </div>
                    <div class="col-md-6">
                        <nav aria-label="breadcrumb" class="float-left float-md-right">
                            <ol class="breadcrumb bg-transparent m-0 p-0">
                                <li class="breadcrumb-item text-white"><a href="#">Home</a></li>
                                <li class="breadcrumb-item active">Submit Property</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div> -->
         <!--	Banner   --->
		 
		 
		<!--	Submit property   -->
        <div class="full-row">
            <div class="container">
                    <div class="row">
						<div class="col-lg-12">
							<h2 class="text-secondary double-down-line text-center">Submit Property</h2>
                        </div>
					</div>
                     	<div class="row">
						<div class="col-md-12">
							<div class="card">
								<div class="card-header">
									<h4 class="card-title">Add Property Details</h4>
								</div>
								 	 <form method="post" enctype="multipart/form-data">
								<div class="card-body">
									<h5 class="card-title">Property Detail</h5>
									<?php echo $error; ?>
									<?php echo $msg; ?>
									
										<div class="row">
											<div class="col-xl-12">
												<div class="form-group row">
													<label class="col-lg-2 col-form-label">Title</label>
													<div class="col-lg-9">
														<input type="text" class="form-control" name="title" required placeholder="Enter Title">
													</div>
												</div>
<?php
													$user_id= $_SESSION['uid'];
													$sql = "SELECT utype FROM user WHERE uid = '$user_id' ";
													if($result =mysqli_query($con,$sql)){
														while($row = mysqli_fetch_assoc($result)){
															 if($row['utype']=='owner'){

															 }
															 else if($row['utype']=='agent'){
															 	echo '
																<div class="form-group row">
																    <label class="col-lg-2 col-form-label">Agent Maharashtra Registration Number (Optional)</label>
																    <div class="col-lg-9">
																        <input type="text" class="form-control" name="agent_reg_number" placeholder="Enter Agent Registration Number">
																    </div>
																</div>';
															 }
															  else if($row['utype']=='builder/developer'){

															  	echo '<div class="form-group row">
																	<label class="col-lg-2 col-form-label ">Project Maharashtra Registration Number (Optional)</label>
																	<div class="col-lg-9">
																		<input type="text" class="form-control" name="project_reg_number"  placeholder="Enter  Maharashtra Registration Number ">
																	</div>
																</div>
																';
																echo '<div class="form-group row">
																	<label class="col-lg-2 col-form-label ">QR Code upload(Optional)</label>
																	<div class="col-lg-9">
																		<input type="file" class="form-control" name="qr_code"  placeholder="Enter  Maharashtra Registration Number ">
																	</div>
																</div> ';
															  
															 }
															 else if($row['utype']=='channel partner'){
															 	echo '
																<div class="form-group row">
																    <label class="col-lg-2 col-form-label">Agent Maharashtra Registration Number (Optional)</label>
																    <div class="col-lg-9">
																        <input type="text" class="form-control" name="agent_reg_number" placeholder="Enter Agent Registration Number">
																    </div>
																</div>';
																  	echo '<div class="form-group row">
																	<label class="col-lg-2 col-form-label ">Project Maharashtra Registration Number (Optional)</label>
																	<div class="col-lg-9">
																		<input type="text" class="form-control" name="project_reg_number"  placeholder="Enter  Maharashtra Registration Number ">
																	</div>
																</div>
																';
																echo '<div class="form-group row">
																	<label class="col-lg-2 col-form-label ">QR Code upload(Optional)</label>
																	<div class="col-lg-9">
																		<input type="file" class="form-control" name="qr_code"  placeholder="Enter  Maharashtra Registration Number ">
																	</div>
																</div> ';
															  
															 }
															  else if($row['utype']=='strategic partner'){
															 	echo '
																<div class="form-group row">
																    <label class="col-lg-2 col-form-label">Agent Maharashtra Registration Number (Optional)</label>
																    <div class="col-lg-9">
																        <input type="text" class="form-control" name="agent_reg_number" placeholder="Enter Agent Registration Number">
																    </div>
																</div>';
																  	echo '<div class="form-group row">
																	<label class="col-lg-2 col-form-label ">Project Maharashtra Registration Number (Optional)</label>
																	<div class="col-lg-9">
																		<input type="text" class="form-control" name="project_reg_number"  placeholder="Enter  Maharashtra Registration Number ">
																	</div>
																</div>
																';
																echo '<div class="form-group row">
																	<label class="col-lg-2 col-form-label ">QR Code upload(Optional)</label>
																	<div class="col-lg-9">
																		<input type="file" class="form-control" name="qr_code"  placeholder="Enter  Maharashtra Registration Number ">
																	</div>
																</div> ';
															  
															 }

														}
													}
													 

												?>
												 
											 
												
												 
												
												<div class="form-group row">
													<label class="col-lg-2 col-form-label">Property Description</label>
													<div class="col-lg-9">
														<textarea class="tinymce form-control" name="content" rows="10" cols="30"></textarea>
													</div>
												</div>
												
											</div>
											<div class="col-xl-6">
												<div class="form-group row">
													<label class="col-lg-3 col-form-label">Property Type</label>
													<div class="col-lg-9">
														<select class="form-control" required name="ptype" id="propertyType" onchange="showSelectedValue()">
									    <option value="">Select Type</option>
									      <optgroup label="Residential">
										    <option value="apartment">Apartment</option>
										    <option value="bungalow">Bungalow</option>
										    <option value="flat">Flats</option>
										    <option value="ghar">Ghar</option>
										    <option value="land">Land</option>
										    <option value="pent-house">Pent House</option>
										    <option value="plots">Plots</option>
										    <option value="row-house">Row House</option>
										    <option value="second-home">Second Home</option>
										    <option value="terrace-flat">Terrace Flat</option>
										    <option value="villa">Villa</option>
										</optgroup>
										 <optgroup label="Commercial">
									        <option value="offices">Offices</option>
									        <option value="plots">Plots</option>
									        <option value="shops">Shops</option>
									        <option value="space">Space</option>
									    </optgroup>
									    <optgroup label="Agriculture">
									        <option value="farm-house">Farm House</option>
									        <option value="land" >Land</option>
									    </optgroup>
									   
									   <optgroup label="Industrial">
									    <option value="company">Company</option>
									    <option value="factory">Factory</option>
									    <option value="godown">Godown</option>
									    <option value="industrial-land">Industrial Land</option>
									    <option value="land">Land</option>
									    <option value="midc">MIDC</option>
									    <option value="na-plots">N.A. Plots</option>
									    <option value="premises">Premises</option>
									    <option value="shed">Shed</option>
									    <option value="ware-house">Ware House</option>
									</optgroup>

									  

									</select>

													</div>
												</div>
												<div id="selling_type"  class="form-group row">
													<label class="col-lg-3 col-form-label">Selling Type</label>
													<div class="col-lg-9">
														<select class="form-control"  name="stype">
															<option value="">Select Status</option>
															<option value="new">New</option>
															<option value="rent">Rental</option>
														 	<option value="re-sale">Re-Sale</option>
                    											<option value="sale">Sale</option>
                    											<option value="buy">Buy</option>
														</select>
													</div>
												</div>
												<div id="selling_type"  class="form-group row">
													<label class="col-lg-3 col-form-label">Facing</label>
													<div class="col-lg-9">
														<select class="form-control"  required name="faceing">
															<option value="">Select..</option>
															<option value="East">East</option>
															<option value="West">West</option>
															<option value="South">South</option>
															<option value="North">North</option>
															 <option value="Northeast">Northeast</option>
													        <option value="Southeast">Southeast</option>
													        <option value="Southwest">Southwest</option>
													        <option value="Northwest">Northwest</option>
														</select>
													</div>
												</div>
												<div id="bathroom" class="form-group row">
													<label class="col-lg-3 col-form-label">Bathroom</label>
													<div class="col-lg-9">
														<input type="text" class="form-control" name="bath"  placeholder="Enter Bathroom (only no 1 to 10)">
													</div>
												</div>
												<div id="kitchen" class="form-group row">
													<label class="col-lg-3 col-form-label">Kitchen</label>
													<div class="col-lg-9">
														<input type="text" class="form-control" name="kitc"  placeholder="Enter Kitchen (only no 1 to 10)">
													</div>
												</div>
												
											</div>   
											<div id="bhk_bedroom_balcony_hall" class="col-xl-6">
												<div class="form-group row mb-3">
													<label class="col-lg-3 col-form-label">BHK</label>
													<div class="col-lg-9">
														<select class="form-control"  name="bhk">
															<option value="">Select BHK</option>
															<option value="1 BHK">1 BHK</option>
															<option value="2 BHK">2 BHK</option>
															<option value="3 BHK">3 BHK</option>
															<option value="4 BHK">4 BHK</option>
															<option value="5 BHK">5 BHK</option>
															<option value="1,2 BHK">1,2 BHK</option>
															<option value="2,3 BHK">2,3 BHK</option>
															<option value="2,3,4 BHK">2,3,4 BHK</option>
														</select>
													</div>
												</div>
												<div class="form-group row">
													<label class="col-lg-3 col-form-label">Bedroom</label>
													<div class="col-lg-9">
														<input type="text" class="form-control" name="bed"  placeholder="Enter Bedroom  (only no 1 to 10)">
													</div>
												</div>
												<div class="form-group row">
													<label class="col-lg-3 col-form-label">Balcony</label>
													<div class="col-lg-9">
														<input type="text" class="form-control" name="balc"  placeholder="Enter Balcony  (only no 1 to 10)">
													</div>
												</div>
												<div class="form-group row">
													<label class="col-lg-3 col-form-label">Hall</label>
													<div class="col-lg-9">
														<input type="text" class="form-control" name="hall"  placeholder="Enter Hall  (only no 1 to 10)">
													</div>
												</div>
												
											</div>

										</div>
									 <div class="row" id="area_unit">
											<div class="col-xl-12">
												<div class="form-group row">
													<label class="col-lg-2 col-form-label">Enter Area</label>
													<div class="col-lg-3">
														<input type="text" class="form-control" name="land_plot_area"  placeholder="Enter Area">
													</div>
												<label class="col-lg-2 col-form-label">Select  Select Area</label>
													<div class="col-lg-3">
															<select class="form-control"  name="type_area">
														  <option value="sqYard">Square Yard (sq yard)</option>
											        <option value="sqMeter">Square Meter (sq meter)</option>
											        <option value="guntha">Guntha</option>
											        <option value="acre">Acre</option>
											        <option value="hectare">Hectare</option>
														</select>
													</div>
										</div>
									</div>
								</div>
										<h4 class="card-title">Price & Location</h4>
										<div class="row">
											<div class="col-xl-6">
												<div class="form-group row" id="select_floor">
													<label class="col-lg-3 col-form-label">Floor</label>
													<div class="col-lg-9">
														
														<input type="number" class="form-control" name="floor"   placeholder="Enter Floor">
													</div>
												</div>
												<div class="form-group row">
													<label class="col-lg-3 col-form-label">Price</label>
													<div class="col-lg-9">
														<input type="text" class="form-control" name="price" required placeholder="Enter Price">
													</div>
												</div>
												<div class="form-group row">
													<label class="col-lg-3 col-form-label">City</label>
													<div class="col-lg-9">
														<input type="text" class="form-control" name="city" required placeholder="Enter City">
													</div>
												</div>
												<div class="form-group row">
													<label class="col-lg-3 col-form-label">State</label>
													<div class="col-lg-9">
														<input type="text" class="form-control" name="state" required placeholder="Enter State">
													</div>
												</div>
											</div>
											<div class="col-xl-6">
												<div class="form-group row " id="select_total_floor">
													<label class="col-lg-3 col-form-label">Total Floor</label>
													<div class="col-lg-9">
														 	 
														<input type="number" class="form-control" name="totalfl"    placeholder="Enter TotalFloor">
													</div>
												</div>
												<div class="form-group row">
													<label class="col-lg-3 col-form-label">Area Size</label>
													<div class="col-lg-9">
														<input type="text" class="form-control" name="asize" required placeholder="Enter Area Size (in Sq.Ft.)">
													</div>
												</div>
												<div class="form-group row">
													<label class="col-lg-3 col-form-label">Address</label>
													<div class="col-lg-9">
														<input type="text" class="form-control" name="loc" required placeholder="Enter Address">
													</div>
												</div>
												
											</div>
										</div>
										
										<div class="form-group row">
											<label class="col-lg-2 col-form-label">Add Amenities (Optional)</label>
											<div class="col-lg-9">
											
											
											<textarea class="tinymce form-control" name="feature" rows="10" cols="30">
												 
												 
											</textarea>
											</div>
										</div>
												
										<h4 class="card-title">Image & Status</h4>
											<p class="text-danger">(the image must be 400 pixels wide and 250  pixels tall)</p>
										<div class="row">
											<div class="col-xl-6">
												
												<div class="form-group row">
													<label class="col-lg-3 col-form-label">Image</label>
													<div class="col-lg-9">
														<input class="form-control" name="aimage" type="file" required="">
													
													</div>

												</div>
												<div class="form-group row">
													<label class="col-lg-3 col-form-label">Image 2</label>
													<div class="col-lg-9">
														<input class="form-control" name="aimage2" type="file" required="">

													</div>
												</div>
												<div class="form-group row">
													<label class="col-lg-3 col-form-label">Image 4</label>
													<div class="col-lg-9">
														<input class="form-control" name="aimage4" type="file" required="">
													</div>
												</div>
												<div class="form-group row">
													<label class="col-lg-3 col-form-label">Status</label>
													<div class="col-lg-9">
														<select class="form-control"  required name="status">
															<option value="">Select Status</option>
															<option value="available">Available</option>
															<option value="sold out">Sold Out</option>
														</select>
													</div>
												</div>
												<div class="form-group row" id="basement_plan">
													<label class="col-lg-3 col-form-label">Basement Floor Plan Image</label>
													<div class="col-lg-9">
														<input class="form-control" name="fimage1" type="file">
													</div>
												</div>
											</div>
											<div class="col-xl-6">
												
												<div class="form-group row">
													<label class="col-lg-3 col-form-label">Image 1</label>
													<div class="col-lg-9">
														<input class="form-control" name="aimage1" type="file" required="">
													</div>
												</div>
												<div class="form-group row">
													<label class="col-lg-3 col-form-label">image 3</label>
													<div class="col-lg-9">
														<input class="form-control" name="aimage3" type="file" required="">
													</div>
												</div>
												 
												<div class="form-group row" id="floor_plan">
													<label class="col-lg-3 col-form-label">Floor Plan Image</label>
													<div class="col-lg-9">
														<input class="form-control" name="fimage" type="file">
													</div>
												</div>
												<div class="form-group row" id="ground_floor">
													<label class="col-lg-3 col-form-label">Ground Floor Plan Image</label>
													<div class="col-lg-9">
														<input class="form-control" name="fimage2" type="file">
													</div>
												</div>
											</div>
										</div>

										<hr>

										 

									 
										<div class="row">
											<div class="col-md-6">
												<div class="form-group row">
													<label class="col-lg-3 col-form-label"><b>Youtube Video </b></label>
													<div class="col-lg-9">
														<input style="height:130px" type="text" class="form-control" name="youtube_code" required placeholder="Paste Embed code of Youtube Video">
													</div>
												</div>
											</div>
										</div>


										
											<input type="submit" value="Submit" class="btn text-white"name="add" style="margin-left:200px;background-color: #004274;">
										
								</div>
								</form>
							</div>
						</div>
					</div>         
            </div>
        </div>
	<!--	Submit property   -->
        
        
        <!--	Footer   start-->
		<?php include("include/footer.php");?>
		<!--	Footer   start-->
        
        <!-- Scroll to top --> 
        <a href="#" class="bg-secondary text-white hover-text-secondary" id="scroll"><i class="fas fa-angle-up"></i></a> 
        <!-- End Scroll To top --> 
    </div>
</div>
<!-- Wrapper End --> 

<!--	Js Link
============================================================--> 
<script src="js/jquery.min.js"></script> 
<script src="js/tinymce/tinymce.min.js"></script>
<script src="js/tinymce/init-tinymce.min.js"></script>
<!--jQuery Layer Slider --> 
<script src="js/greensock.js"></script> 
<script src="js/layerslider.transitions.js"></script> 
<script src="js/layerslider.kreaturamedia.jquery.js"></script> 
<!--jQuery Layer Slider --> 
<script src="js/popper.min.js"></script> 
<script src="js/bootstrap.min.js"></script> 
<script src="js/owl.carousel.min.js"></script> 
<script src="js/tmpl.js"></script> 
<script src="js/jquery.dependClass-0.1.js"></script> 
<script src="js/draggable-0.1.js"></script> 
<script src="js/jquery.slider.js"></script> 
<script src="js/wow.js"></script> 
<script src="js/custom.js"></script>
	 <script type="text/javascript">
			window.addEventListener("load", (event) => {
			 document.getElementById('area_unit').style.display='none';
			});

			  function showSelectedValue() {
            var selectElement = document.getElementById("propertyType");
            var selectedValue = selectElement.options[selectElement.selectedIndex].value;
           	if(selectedValue=='plots'){
           		// alert(selectedValue);
           		document.getElementById('bhk_bedroom_balcony_hall').style.display='none';
           		document.getElementById('kitchen').style.display='none';
           		document.getElementById('bathroom').style.display='none';
           		// document.getElementById('selling_type').style.display='bl';
           		document.getElementById('select_floor').style.display='none';
           		document.getElementById('select_total_floor').style.display='none';
           		document.getElementById('ground_floor').style.display='none';
           		document.getElementById('basement_plan').style.display='none';
           		document.getElementById('floor_plan').style.display='none';
           		document.getElementById('area_unit').style.display='block';
           	}
           	else if(selectedValue=='land'){
           		document.getElementById('bhk_bedroom_balcony_hall').style.display='none';
           		document.getElementById('kitchen').style.display='none';
           		document.getElementById('bathroom').style.display='none';
           		// document.getElementById('selling_type').style.display='none';
           		document.getElementById('select_floor').style.display='none';
           		document.getElementById('select_total_floor').style.display='none';
           		document.getElementById('ground_floor').style.display='none';
           		document.getElementById('basement_plan').style.display='none';
           		document.getElementById('floor_plan').style.display='none';
           	   document.getElementById('area_unit').style.display='block';
           	}
           		else if(selectedValue=='na-plots'){
           		document.getElementById('bhk_bedroom_balcony_hall').style.display='none';
           		document.getElementById('kitchen').style.display='none';
           		document.getElementById('bathroom').style.display='none';
           		// document.getElementById('selling_type').style.display='none';
           		document.getElementById('select_floor').style.display='none';
           		document.getElementById('select_total_floor').style.display='none';
           		document.getElementById('ground_floor').style.display='none';
           		document.getElementById('basement_plan').style.display='none';
           		document.getElementById('floor_plan').style.display='none';
           	   document.getElementById('area_unit').style.display='block';
           	}
           	else{
           		
           		document.getElementById('kitchen').removeAttribute("style");
           		document.getElementById('bathroom').removeAttribute("style");
           		document.getElementById('selling_type').removeAttribute("style");
           		document.getElementById('bhk_bedroom_balcony_hall').removeAttribute("style");
           		document.getElementById('area_unit').style.display='none';
           		document.getElementById('select_floor').removeAttribute("style");
           		document.getElementById('select_total_floor').removeAttribute("style");
           		document.getElementById('floor_plan').removeAttribute("style");
           		document.getElementById('basement_plan').removeAttribute("style");
           		document.getElementById('ground_floor').removeAttribute("style");

           	}

        }
		</script>
</body>
</html>