<?php
include("config.php");

session_start();
// Generate a CSRF token and store it in a session variable
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
  $errors = "";
// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["csrf_token"]) && $_POST["csrf_token"] === $_SESSION["csrf_token"]) {
    

  

    // Validate and sanitize each input field
    $stype = filter_var($_POST["stype"], FILTER_SANITIZE_STRING);
    $information = filter_var($_POST["information"], FILTER_SANITIZE_STRING);
    $first_name = filter_var($_POST["first_name"], FILTER_SANITIZE_STRING);
    $last_name = filter_var($_POST["last_name"], FILTER_SANITIZE_STRING);
    $email = filter_var($_POST["email"], FILTER_VALIDATE_EMAIL);
    $phone = filter_var($_POST["phone"], FILTER_SANITIZE_STRING);
    $country = filter_var($_POST["country"], FILTER_SANITIZE_STRING);
    $state = filter_var($_POST["state"], FILTER_SANITIZE_STRING);
    $city = filter_var($_POST["city"], FILTER_SANITIZE_STRING);
    $area = filter_var($_POST["area"], FILTER_SANITIZE_STRING);
    $zip_code = filter_var($_POST["zip_code"], FILTER_SANITIZE_STRING);
    $ptype = filter_var($_POST["ptype"], FILTER_SANITIZE_STRING);
    $max_price = filter_var($_POST["max_price"], FILTER_SANITIZE_STRING);
    $min_size = filter_var($_POST["min_size"], FILTER_SANITIZE_STRING);
    $num_beds = filter_var($_POST["num_beds"], FILTER_SANITIZE_STRING);
    $num_baths = filter_var($_POST["num_baths"], FILTER_SANITIZE_STRING);
    $message = filter_var($_POST["message"], FILTER_SANITIZE_STRING);
    $gdpr_agreement = isset($_POST["gdpr_agreement"]) ? "Yes" : "No";
    $gdpr_agreement = isset($_POST["gdpr_agreement"]) ? "Yes" : "No";

    // Check for missing fields and add error messages
    if ($stype === "") {
        $errors= "<p class='alert alert-warning'>Inquiry Type can not be empty</p>";
    }
    if ($information === "") {
        $errors= "<p class='alert alert-warning'>Information can not be empty</p>";
    }
    if ($first_name === "") {
        $error = "<p class='alert alert-warning'>First Name can not be empty</p>";
    }
    if ($last_name === "") {
        $error = "<p class='alert alert-warning'>Last Name can not be empty</p>";
    }
    if ($email === "") {
        $errors= "<p class='alert alert-warning'>Email Address can not be empty</p>";
    }
    if ($phone === "") {
        $errors= "<p class='alert alert-warning'>Mobile can not be empty</p>";
    }
    if ($country === "") {
        $error = "<p class='alert alert-warning'>Country can not be empty</p>";
    }
    if ($state === "") {
        $error = "<p class='alert alert-warning'>State can not be empty</p>";
    }
    if ($city === "") {
        $errors= "<p class='alert alert-warning'>City can not be empty</p>";
    }
    if ($area === "") {
        $errors = "<p class='alert alert-warning'>Area can not be empty</p>";
    }
    if ($zip_code === "") {
        $errors = "<p class='alert alert-warning'>Zip Code can not be empty</p>";
    }
    if ($ptype === "") {
        $errors = "<p class='alert alert-warning'>Property Type can not be empty</p>";
    }
    if ($max_price === "") {
        $errors = "<p class='alert alert-warning'>Max Price can not be empty</p>";
    }
    if ($min_size === "") {
        $errors = "<p class='alert alert-warning'>Minimum Size (Sq Ft) can not be empty</p>";
    }
    if ($num_beds === "") {
        $errors = "<p class='alert alert-warning'>Number of Beds can not be empty</p>";
    }
    if ($num_baths === "") {
        $errors = "<p class='alert alert-warning'>Number of Baths can not be empty</p>";
    }
    if ($message === "") {
        $errors = "<p class='alert alert-warning'>Message can not be empty</p>";
    }
    else{
    	  $sql = "INSERT INTO inquiry 
            VALUES (NULL,'$stype', '$information', '$first_name', '$last_name', '$email', '$phone', '$country', '$state', '$city', '$area', '$zip_code', '$ptype', '$max_price', '$min_size', '$num_beds', '$num_baths', '$message', '$gdpr_agreement')";
            if(mysqli_query($con,$sql)){
 					$errors = "<p class='alert alert-success'>Your Inquiry Submitted</p>";
            }
            else{
            	 $errors = "<p class='alert alert-warning'>Error</p>";
            }


    }

}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<!-- Required meta tags -->
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<!-- Meta Tags -->
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<link rel="shortcut icon" href="images/favicon.ico">

<!--	Fonts
	========================================================-->
<link href="https://fonts.googleapis.com/css?family=Muli:400,400i,500,600,700&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Comfortaa:400,700" rel="stylesheet">

<!--	Css Link
	========================================================-->
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="css/bootstrap-slider.css">
<link rel="stylesheet" type="text/css" href="css/jquery-ui.css">
<link rel="stylesheet" type="text/css" href="css/layerslider.css">
<link rel="stylesheet" type="text/css" href="css/color.css" id="color-change">
<link rel="stylesheet" type="text/css" href="css/owl.carousel.min.css">
<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="fonts/flaticon/flaticon.css">
<link rel="stylesheet" type="text/css" href="css/style.css">

<!--	Title
	=========================================================-->
<title>Inquiry Form</title>
</head>
<body>

<!--	Page Loader
=============================================================
<div class="page-loader position-fixed z-index-9999 w-100 bg-white vh-100">
	<div class="d-flex justify-content-center y-middle position-relative">
	  <div class="spinner-border" role="status">
		<span class="sr-only">Loading...</span>
	  </div>
	</div>
</div>
--> 

<div id="page-wrapper">
    <div class="row"> 
        <!--	Header start  -->
		<?php include("include/header.php");?>
        <!--	Header end  -->
        
        <!--	Banner -->
        <!-- <div class="banner-full-row page-banner" style="background-image:url('images/breadcromb.jpg');">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <h2 class="page-name float-left text-white text-uppercase mt-1 mb-0"><b>Contact</b></h2>
                    </div>
                    <div class="col-md-6">
                        <nav aria-label="breadcrumb" class="float-left float-md-right">
                            <ol class="breadcrumb bg-transparent m-0 p-0">
                                <li class="breadcrumb-item text-white"><a href="#">Home</a></li>
                                <li class="breadcrumb-item active">Contact</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div> -->
        <!--	Banner -->
		
        <!--	Contact Information -->
        <div class="full-row">

            <div class="container">
                <div class="row">
                    <div class="col-md-2"></div>
                    <div class="col-md-8">
						<div class="container">
                        <div class="row">
							<div class="col-lg-12">
								<h2 class="text-secondary double-down-line text-center mb-5">Inquiry Form</h2>
						
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
							<form class="w-100" method="post" >
								            <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">


    <div class="row">
        <div class="row mb-4">
            <div class="form-group col-md-12">
                <label class="text-dark font-weight-bold" for="stype">Inquiry Type</label>
                <select class="form-control" required name="stype" id="stype">
                    <option value="" disabled selected>Select Status</option>
                      
                                                            <option value="new">New</option>
                                                            <option value="rent">Rental</option>
                                                            <option value="re-sale">Re-Sale</option>
                                                                <option value="sale">Sale</option>
                                                                <option value="buy">Buy</option>
                </select>
            </div>
            <div class="form-group col-md-12">
                <label class="text-dark font-weight-bold" for="information">Information</label>
                <input type="text" name="information" class="form-control" placeholder="I'm a" id="information" required>
            </div>
            <!-- first name -->
            <div class="form-group col-lg-6">
                <input type="text" name="first_name" class="form-control" placeholder="First Name" id="first_name" required>
            </div>
            <!-- last name -->
            <div class="form-group col-lg-6">
                <input type="text" name="last_name" class="form-control" placeholder="Last Name" id="last_name" required>
            </div>
            <!-- email address -->
            <div class="form-group col-lg-6">
                <input type="email" name="email" class="form-control" placeholder="Email Address" id="email" required>
            </div>
            <div class="form-group col-lg-6">
                <input type="tel" name="phone" class="form-control" placeholder="Mobile" id="phone" maxlength="10" required>
            </div>
            <div class="col-lg-12">
                <label class="text-dark font-weight-bold">Location</label>
            </div>
       <div class="form-group col-lg-4">
                <select class="form-control form-select country" aria-label="Default select example" onchange="loadStates()" name="country" id="country" required>
                    <option value="" selected>India</option>
                  <!-- Add country options here -->
                </select>
            </div> 
            <div class="form-group col-lg-4">
                <select class="form-control form-select state" aria-label="Default select example" onchange="loadCities()" name="state" id="state" required>
                    <option value="" disabled selected>Select State</option>
                    <!-- Add state options here -->
                </select>
            </div>
            <div class="form-group col-lg-4">
                <select class="form-control form-select city" aria-label="Default select example" name="city" id="city" required>
                    <option value="" disabled selected>Select City</option>
                    <!-- Add city options here -->
                </select>
            </div>
            <div class="form-group col-lg-6">
                <input type="text" name="area" class="form-control" placeholder="Enter Location
                " id="area" required>
            </div>
            <div class="form-group col-lg-6">
                <input type="text" name="zip_code" class="form-control" placeholder="Zip Code" id="zip_code" required>
            </div>
            <div class="col-lg-12">
                <label class="text-dark font-weight-bold">Property</label>
            </div>
            <div class="form-group col-lg-12">
                 <select class="form-control" required name="ptype">
															 <option value="">Select Type</option>
													    <optgroup label="Agriculture">
													        <option value="farm-house">Farm House</option>
													        <option value="land">Land</option>
													    </optgroup>
													    <optgroup label="Commercial">
													        <option value="offices">Offices</option>
													        <option value="plots">Plots</option>
													        <option value="shops">Shops</option>
													         <option value="space">Space</option>
													    </optgroup>
													      <optgroup label="Industrial">
														    <option value="company">Company</option>
														    <option value="factory">Factory</option>
														    <option value="godown">Godown</option>
														    <option value="industrial-land">Industrial Land</option>
														    <option value="land">Land</option>
														    <option value="midc">MIDC</option>
														    <option value="na-plots">N.A. Plots</option>
														    <option value="premises">Premises</option>
														    <option value="shed">Shed</option>
														    <option value="ware-house">Ware House</option>
														</optgroup>
													     <optgroup label="Residential">
													    <option value="apartment">Apartment</option>
													    <option value="bungalow">Bungalow</option>
													    <option value="flats">Flats</option>
													    <option value="ghar">Ghar</option>
													    <option value="land">Land</option>
													    <option value="pent-house">Pent House</option>
													    <option value="plots">Plots</option>
													    <option value="row-house">Row House</option>
													    <option value="second-home">Second Home</option>
													    <option value="terrace-flat">Terrace Flat</option>
													    <option value="villa">Villa</option>
													</optgroup>
																	</select>
            </div>
            <div class="col-lg-6">
                <div class="form-group">
                    <input type="text" name="max_price" class="form-control" placeholder="Budget" id="max_price" required>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="form-group">
                    <input type="text" name="min_size" class="form-control" placeholder="Minimum Size (Sq Ft)" id="min_size" required>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="form-group">
                    <input type="number" min="0" name="num_beds" class="form-control" placeholder="Number of Beds" id="num_beds" required>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="form-group">
                    <input type="number" min="0" name="num_baths" class="form-control" placeholder="Number of Bathrooms" id="num_baths" required>
                </div>
            </div>
            <div class="col-lg-12">
                <label class="text-dark font-weight-bold">Message</label>
            </div>
            <div class="col-lg-12">
                <div class="form-group">
                    <textarea name="message" class="form-control" rows="5" placeholder="Type Comments..." id="message" required></textarea>
                </div>
            </div>
            <div class="col-lg-12">
                <label class="text-dark font-weight-bold">Terms & Conditions</label>
            </div>
            <div class="col-lg-12">
                <div class="form-group">
                    <input type="checkbox" name="gdpr_agreement" required>
                    I consent to having this website store my submitted information
                </div>
            </div>
        </div>
        <button type="submit" value="send message" name="send" class="btn text-light" style="background-color:#004274">Send Message</button>
        <div class="col-lg-12 mt-3 form-group">
                 <?php echo $errors; ?>
            </div>
    </div>
</form>


							</div>
						</div>
						</div>
					</div>
                          <div class="col-md-2"></div>
                </div>
            </div>
        </div>
        <!--	Contact Inforamtion -->
        
        <!--	Map 
		<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d5644.408542716626!2d-117.1523848363907!3d32.73426737275872!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x80d95495497f80c9%3A0x5df0f4372635e247!2sSan%20Diego%20Zoo!5e0!3m2!1sen!2snp!4v1658568764228!5m2!1sen!2snp" width="100%" height="400" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
		Map -->
        
        <!--	Footer   start-->
		<?php include("include/footer.php");?>
		<!--	Footer   start-->
        
        <!-- Scroll to top --> 
        <a href="#" class="bg-secondary text-white hover-text-secondary" id="scroll"><i class="fas fa-angle-up"></i></a> 
        <!-- End Scroll To top --> 
    </div>
</div>
<!-- Wrapper End --> 

<!--	Js Link
============================================================--> 
<script src="js/jquery.min.js"></script> 
<!--jQuery Layer Slider --> 
<script src="js/greensock.js"></script> 
<script src="js/layerslider.transitions.js"></script> 
<script src="js/layerslider.kreaturamedia.jquery.js"></script> 
<!--jQuery Layer Slider --> 
<script src="js/popper.min.js"></script> 
<script src="js/bootstrap.min.js"></script> 
<script src="js/owl.carousel.min.js"></script> 
<script src="js/tmpl.js"></script> 
<script src="js/jquery.dependClass-0.1.js"></script> 
<script src="js/draggable-0.1.js"></script> 
<script src="js/jquery.slider.js"></script> 
<script src="js/wow.js"></script> 
<script src="js/jquery.cookie.js"></script> 
<script src="js/custom.js"></script>  
<script src="js/app.js"></script>
</body>
</html>