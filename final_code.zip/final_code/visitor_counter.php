<?php
// File path to the counter text file
$counterFile = "counter.txt";

// Read the current count from the file
$currentCount = (int) file_get_contents($counterFile);

// Increment the count by 1
$newCount = $currentCount + 1;

// Update the counter file with the new count
file_put_contents($counterFile, $newCount);
								
?>