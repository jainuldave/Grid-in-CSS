
<?php include("visitor_counter.php");?>

<footer class="full-row p-0" style="background-color:#004274">
            <div class="container">
                <div  class="row">
                    <div class="col-lg-12">
                        <div class="divider py-40">
                            <div class="row">
                                <div class="col-md-12 col-lg-4">
                                    <div class="footer-widget mb-4">
                                        <div class="footer-logo mb-4"> <a href="#"><img class="logo-bottom" src="images/logo/Property Maharashtra Website Logo White.png" alt="image" style="width:150px; height:auto;"></a> </div>
                                        <p class="pb-20 text-white">PropertyMaharashtra is your go-to hub for all things real estate. Whether you're a first-time buyer, seasoned investor, or simply passionate about property, we've got you covered.</p>
                                        <div class="footer-widget media-widget mt-4 text-white  ">
                                            <a href="#"><i class="fab fa-whatsapp"></i></a>
                                            <a href="#"><i class="fab fa-youtube"></i></a>
                                            <a href="#"><i class="fab fa-facebook-f"></i></a>
                                            <a href="#"><i class="fab fa-instagram"></i></a>
                                            <a href="#"><i class="fab fa-telegram"></i></a>
                                            <a href="#"><i class="fab fa-twitter"></i></a>
                                            <a href="#"><i class="fab fa-linkedin-in"></i></a>
                                            <a href="#"><i class="fab fa-koo"></i></a> 
                                            </div>          
                                      
										
                                        </div>
                                </div>
                                <div class="col-md-12 col-lg-8">
                                    <div class="row">
                                        <div class="col-md-4 col-lg-3">
                                            <div class="footer-widget footer-nav mb-4">
                                                <h4 class="widget-title text-white double-down-line-left position-relative">Policies</h4>
                                                <ul class=" " >
                                                    <li ><a href="#" class="text-white" >Privacy Policy</a></li>
                                                    <li><a href="#" class="text-white">Terms and Condition</a></li>
                                                    <li></li>
                                                    <li></li>
                                                    <li><div id="google_translate_element" ></div></li>
                                     
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="col-md-4 col-lg-3">
                                            <div class="footer-widget footer-nav mb-4">
                                                <h4 class="widget-title text-white double-down-line-left position-relative">Quick Links</h4>
                                                <ul class=" ">
                                                    <li><a href="about.php" class="text-white">About Us</a></li>
                                                    <li><a href="blog.php" class="text-white">Blogs</a></li>
                                                    <li><a href="inquiry.php" class="text-white">Inquiry</a></li>
                                                    <li><a href="contact.php" class="text-white">Contact Us</a></li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="col-md-4 col-lg-6">
                                            <div class="footer-widget">
                                                <h4 class="widget-title text-white double-down-line-left position-relative">Contact Us</h4>
                                                <ul class="text-white">
                                                    <li class=" "><i class="fas fa-map-marker-alt text-white mr-2 font-13 mt-1"></i>Nashik, Maharashtra, India</li>
                                                    <li class=" "> <i class="fas fa-phone-alt text-white mr-2 font-13 mt-1"></i>+91 98222 63744</li>
													
                                                    <li class=" "><i class="fas fa-envelope text-white mr-2 font-13 mt-1"></i>info@propertymaharashtra.com</li>
                                                </ul>
                                            </div>
                                            

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row copyright">
                    <div class="col-sm-6"> <span class="text-white">© <?php echo date('Y');?> Property Maharashtra - <a href="https://digitalcreations.co.in" target="_blank">Developed by Digital Creations, Nashik </a></span> </div>
                    <div class="col-sm-6">
                        <ul class="line-menu text-white   float-right">
                            <li><h5 class="text-white">Total Visitors &nbsp; <?php echo $newCount; ?></h5></li>
                        
                        </ul>
                    </div>
                </div>
            </div>
        </footer>
        <script type="text/javascript">
function googleTranslateElementInit() {
  new google.translate.TranslateElement({pageLanguage: 'en',includedLanguages : 'hi,en,gu,mr', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element');
}
</script>

<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
